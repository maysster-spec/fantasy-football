"""Task #3: keeper value persistence. Joins draft_history to the season-VBD table and measures
retention (keeper season vs prior season) with survivorship controls."""
import pandas as pd, numpy as np, re, sys
D='/tmp/claude-0/-home-claude/7a129960-8604-52db-9d4d-5fd560a4a85d/scratchpad/k3/'
SRC='/mnt/user-data/uploads/2026/Source/'
def norm(s):
    s=re.sub(r'\s+(Jr\.?|Sr\.?|II|III|IV|V)$','',str(s).strip(),flags=re.I)
    return re.sub(r"[.'’\-\s]",'',s).lower()
S=pd.read_csv(D+'vbd_seasons.csv'); ident=pd.read_csv(D+'ident.csv')
H=pd.read_csv(SRC+'draft_history_2021_2025.csv'); H['nk']=H.Player.map(norm)
H['Pos']=H.Pos.str.upper().str.strip()
# ---- identity: (nk,pos) -> player_id; resolve collisions by activity in the draft year
cand=ident.groupby(['nk','pos']).player_id.apply(list).to_dict()
def resolve(r):
    c=cand.get((r.nk,r.Pos),[])
    if not c: return None
    if len(c)==1: return c[0]
    act=S[(S.player_id.isin(c))&(S.season==r.Year)]
    return act.sort_values('pts14').player_id.iloc[-1] if len(act) else c[0]
H['pid']=H.apply(resolve,axis=1)
sk=H[H.Pos.isin(['QB','RB','WR','TE'])]
un=sk[sk.pid.isna()]
print(f"draft rows QB/RB/WR/TE: {len(sk)}  unmatched to nflverse identity: {len(un)}")
if len(un): print(un[['Year','Rd','Player','Pos']].to_string(index=False))
V=S.set_index(['player_id','season'])
def vbd(pid,yr):
    try: return float(V.loc[(pid,yr),'vbd14'])
    except KeyError:
        # no REG rows that season -> 0 points -> vbd = -replacement (true zero season)
        rp=S[(S.season==yr)&(S.pos==pos_of[pid])].repl14.iloc[0]; return -float(rp)
def field(pid,yr,col):
    try: return V.loc[(pid,yr),col]
    except KeyError: return np.nan
pos_of=ident.set_index('player_id').pos.to_dict()
ever=set(S.player_id)  # anyone with a REG row 2021-2025
# ---- keepers 2022-2025: value in keep season and the season before
K=H[(H.Keeper)&(H.Year>=2022)&(H.Pos.isin(['QB','RB','WR','TE']))].copy()
prior=H[H.Year<2025][['Year','nk','Pos','Rd','Pick']].rename(columns={'Year':'py','Rd':'prior_rd','Pick':'prior_pick'})
prior['Year']=prior.py+1
K=K.merge(prior[['Year','nk','Pos','prior_rd','prior_pick']],on=['Year','nk','Pos'],how='left')
K['v_prior']=[vbd(p,y-1) for p,y in zip(K.pid,K.Year)]
K['v_keep']=[vbd(p,y) for p,y in zip(K.pid,K.Year)]
K['g_prior']=[field(p,y-1,'g14') for p,y in zip(K.pid,K.Year)]
K['g_keep']=[field(p,y,'g14') for p,y in zip(K.pid,K.Year)]
K['rank_prior']=[field(p,y-1,'rank14') for p,y in zip(K.pid,K.Year)]
K['rank_keep']=[field(p,y,'rank14') for p,y in zip(K.pid,K.Year)]
K.to_csv(D+'keepers_valued.csv',index=False)
pd.set_option('display.width',220)
print("\n=== the 48 keepers, 2022-2025 (v = VBD, weeks 1-14, vs same-season RB30/WR30/QB12/TE12) ===")
print(K[['Year','Player','Pos','prior_rd','v_prior','rank_prior','g_prior','v_keep','rank_keep','g_keep']].round(1).sort_values(['Pos','Year']).to_string(index=False))

def boot_stats(vp,vk,B=6000,seed=1):
    vp=np.asarray(vp,float); vk=np.asarray(vk,float); n=len(vp); rng=np.random.default_rng(seed)
    idx=rng.integers(0,n,(B,n))
    ratio=vk[idx].mean(1)/vp[idx].mean(1); diff=(vk-vp)[idx].mean(1); mk=vk[idx].mean(1)
    return dict(n=n,mean_prior=vp.mean(),mean_keep=vk.mean(),
                ratio=vk.mean()/vp.mean(),ratio_lo=np.quantile(ratio,.025),ratio_hi=np.quantile(ratio,.975),
                diff=(vk-vp).mean(),diff_lo=np.quantile(diff,.025),diff_hi=np.quantile(diff,.975),
                keep_lo=np.quantile(mk,.025),keep_hi=np.quantile(mk,.975),
                share_pos=(vk>0).mean())
rows=[]
for p,g in K.groupby('Pos'): rows.append(dict(pos=p,**boot_stats(g.v_prior,g.v_keep)))
rows.append(dict(pos='ALL',**boot_stats(K.v_prior,K.v_keep)))
R=pd.DataFrame(rows); print("\n=== retention by position (kept players) ==="); print(R.round(2).to_string(index=False))

# ---- LEAGUE CONTROL: round-5+ draftees in year y-1 who HIT (v_prior>0) and were NOT kept in y
rows=[]
for y in (2022,2023,2024,2025):
    kept=set(K[K.Year==y].pid)
    d=H[(H.Year==y-1)&(H.Rd>=5)&(H.Pos.isin(['QB','RB','WR','TE']))&H.pid.notna()&(~H.Keeper)]
    for _,r in d.iterrows():
        vp=vbd(r.pid,y-1)
        rows.append(dict(Year=y,Player=r.Player,Pos=r.Pos,prior_rd=r.Rd,pid=r.pid,v_prior=vp,v_keep=vbd(r.pid,y),
                         kept=int(r.pid in kept),g_prior=field(r.pid,y-1,'g14'),g_keep=field(r.pid,y,'g14')))
L=pd.DataFrame(rows); L.to_csv(D+'league_pool.csv',index=False)
hits=L[L.v_prior>0]
print(f"\n=== LEAGUE POOL: round-5+ draftees who HIT (v_prior>0): n={len(hits)}  kept={hits.kept.sum()}  not kept={len(hits)-hits.kept.sum()} ===")
rows=[]
for (p,kf),g in hits.groupby(['Pos','kept']):
    if len(g)>=3: rows.append(dict(pos=p,kept=kf,**boot_stats(g.v_prior,g.v_keep)))
for kf,g in hits.groupby('kept'): rows.append(dict(pos='ALL',kept=kf,**boot_stats(g.v_prior,g.v_keep)))
print(pd.DataFrame(rows).round(2).to_string(index=False))
# matched: for each kept hit, the 3 nearest non-kept same-pos hits by v_prior (same year pool, any year if thin)
mrows=[]
nk_=hits[hits.kept==0]
for _,r in hits[hits.kept==1].iterrows():
    c=nk_[(nk_.Pos==r.Pos)].copy(); c['d']=(c.v_prior-r.v_prior).abs(); c=c.nsmallest(3,'d')
    mrows.append(dict(Pos=r.Pos,kept_prior=r.v_prior,kept_keep=r.v_keep,m_prior=c.v_prior.mean(),m_keep=c.v_keep.mean(),n_m=len(c)))
M=pd.DataFrame(mrows)
print("\n=== matched control (3 nearest non-kept hits by prior VBD, same position) ===")
for p,g in M.groupby('Pos'):
    print(f"{p}: n={len(g)}  kept: prior {g.kept_prior.mean():.1f} -> keep {g.kept_keep.mean():.1f}   matched non-kept: prior {g.m_prior.mean():.1f} -> next {g.m_keep.mean():.1f}")
print(f"ALL: n={len(M)}  kept: prior {M.kept_prior.mean():.1f} -> keep {M.kept_keep.mean():.1f}   matched: prior {M.m_prior.mean():.1f} -> next {M.m_keep.mean():.1f}")
