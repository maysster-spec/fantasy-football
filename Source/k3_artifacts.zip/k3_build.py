"""Task #3 build: nflverse weekly 2021-2025 -> §2 league points -> weeks 1-14 REG totals ->
per-season empirical replacement (RB30 / WR30 / QB12 / TE12 by wk1-14 total) -> VBD."""
import pandas as pd, numpy as np, re, warnings
warnings.filterwarnings('ignore')
D='/tmp/claude-0/-home-claude/7a129960-8604-52db-9d4d-5fd560a4a85d/scratchpad/k3/'

def norm(s):
    s=re.sub(r'\s+(Jr\.?|Sr\.?|II|III|IV|V)$','',str(s).strip(),flags=re.I)
    return re.sub(r"[.'’\-\s]",'',s).lower()

keep=['player_id','player_display_name','position','season','week','season_type',
      'passing_yards','passing_tds','interceptions','rushing_yards','rushing_tds','receptions','receiving_yards','receiving_tds',
      'rushing_fumbles_lost','receiving_fumbles_lost','sack_fumbles_lost',
      'passing_2pt_conversions','rushing_2pt_conversions','receiving_2pt_conversions','special_teams_tds']
fr=[]
for y in (2021,2022,2023,2024):
    d=pd.read_parquet(D+f'w{y}.parquet'); d['team']=d['recent_team']; fr.append(d[keep+['team']])
d=pd.read_parquet(D+'sp2025.parquet').rename(columns={'passing_interceptions':'interceptions'})
fr.append(d[keep+['team']])
w=pd.concat(fr,ignore_index=True)
w=w[(w.season_type=='REG')&(w.position.isin(['QB','RB','WR','TE']))].copy()
for c in keep[6:]: w[c]=w[c].fillna(0).astype(float)
w['pts']=(0.04*w.passing_yards+6*w.passing_tds-2*w.interceptions
          +0.1*w.rushing_yards+6*w.rushing_tds+0.5*w.receptions+0.1*w.receiving_yards+6*w.receiving_tds
          -2*(w.rushing_fumbles_lost+w.receiving_fumbles_lost+w.sack_fumbles_lost)
          +2*(w.passing_2pt_conversions+w.rushing_2pt_conversions+w.receiving_2pt_conversions)
          +6*w.special_teams_tds)
w14=w[w.week<=14]
# player identity: one position per player_id (mode), display name (latest)
ident=(w.sort_values('season').groupby('player_id').agg(name=('player_display_name','last'),
       pos=('position',lambda x:x.mode().iloc[0])).reset_index())
ident['nk']=ident.name.map(norm)
# season table
s=(w14.groupby(['player_id','season']).agg(pts14=('pts','sum'),g14=('week','nunique'),
     team=('team','last')).reset_index().merge(ident,on='player_id'))
# full-season (wk1-17/18) too, and games played all season
sf=w.groupby(['player_id','season']).agg(pts_full=('pts','sum'),g_full=('week','nunique')).reset_index()
s=s.merge(sf,on=['player_id','season'])
s['ppg14']=s.pts14/s.g14
CUT={'QB':12,'RB':30,'WR':30,'TE':12}
s['rank14']=s.groupby(['season','pos']).pts14.rank(ascending=False,method='first')
repl=(s[s.apply(lambda r:r.rank14==CUT[r.pos],axis=1)][['season','pos','pts14','ppg14']]
      .rename(columns={'pts14':'repl14','ppg14':'repl_ppg_at_cut'}))
# ppg replacement: the CUT-th ppg among players with >=8 games in wk1-14
rp=[]
for (yr,p),g in s[s.g14>=8].groupby(['season','pos']):
    v=np.sort(g.ppg14.values)[::-1]; rp.append(dict(season=yr,pos=p,repl_ppg=v[CUT[p]-1] if len(v)>=CUT[p] else np.nan))
repl=repl.merge(pd.DataFrame(rp),on=['season','pos'])
s=s.merge(repl,on=['season','pos'])
s['vbd14']=s.pts14-s.repl14
s['vbd_ppg']=s.ppg14-s.repl_ppg
s.to_csv(D+'vbd_seasons.csv',index=False); ident.to_csv(D+'ident.csv',index=False)
print(repl.sort_values(['pos','season']).round(2).to_string(index=False))
print('player-seasons:',len(s),' players:',s.player_id.nunique())
# sanity: top-3 RB each season by pts14
for yr in range(2021,2026):
    t=s[(s.season==yr)&(s.pos=='RB')].nlargest(3,'pts14')
    print(yr,[(r['name'],round(r.pts14,1),round(r.vbd14,1)) for _,r in t.iterrows()])
