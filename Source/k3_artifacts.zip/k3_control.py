"""Task #3 controls: (1) §4.18 anchor on the 14-week scale, (2) per-game retention for kept RBs,
(3) NFL-wide late-ADP hits via the sanctioned registry (§1.1), with early-ADP regression benchmark,
(4) Matt's own keepers."""
import pandas as pd, numpy as np, re, sys, os
D='/tmp/claude-0/-home-claude/7a129960-8604-52db-9d4d-5fd560a4a85d/scratchpad/k3/'
SRC='/mnt/user-data/uploads/2026/Source/'
sys.path.insert(0,SRC)
os.environ['ADP_REGISTRY']=SRC+'adp_registry'
from code_adp_guard import load_preseason_adp
def norm(s):
    s=re.sub(r'\s+(Jr\.?|Sr\.?|II|III|IV|V)$','',str(s).strip(),flags=re.I)
    return re.sub(r"[.'’\-\s]",'',s).lower()
S=pd.read_csv(D+'vbd_seasons.csv'); K=pd.read_csv(D+'keepers_valued.csv')
pd.set_option('display.width',220)

# (1) the +85 anchor: what an RB5-RB10 finisher is worth on THIS scale (wk1-14 actuals, same-season RB30)
a=S[(S.pos=='RB')&(S.rank14.between(5,10))]
print(f"§4.18 anchor on the 14-week scale: RB5-RB10 finishers 2021-2025, n={len(a)}, mean VBD14 = {a.vbd14.mean():.1f} (range by season {a.groupby('season').vbd14.mean().round(1).to_dict()})")
a2=S[(S.pos=='RB')&(S.rank14.between(11,20))]; print(f"   RB11-20 finishers: mean VBD14 = {a2.vbd14.mean():.1f};  RB21-30: {S[(S.pos=='RB')&(S.rank14.between(21,30))].vbd14.mean():.1f}")

# (2) kept RBs: per-game retention and the late-round subset
V=S.set_index(['player_id','season'])
def f(pid,yr,col):
    try: return V.loc[(pid,yr),col]
    except KeyError: return np.nan
rb=K[K.Pos=='RB'].copy()
rb['ppg_prior']=[f(p,y-1,'vbd_ppg') for p,y in zip(rb.pid,rb.Year)]
rb['ppg_keep']=[f(p,y,'vbd_ppg') for p,y in zip(rb.pid,rb.Year)]
print("\nkept RBs (n=%d): mean VBD14 prior %.1f -> keep %.1f | per-game VBD prior %.2f -> keep %.2f | games14 prior %.1f -> keep %.1f"%(
    len(rb),rb.v_prior.mean(),rb.v_keep.mean(),rb.ppg_prior.mean(),rb.ppg_keep.mean(),rb.g_prior.mean(),rb.g_keep.mean()))
late=rb[rb.prior_rd>=9]
print("kept RBs drafted rd 9+ the year before (n=%d): VBD14 prior %.1f -> keep %.1f ; median keep %.1f ; share >0: %.2f"%(
    len(late),late.v_prior.mean(),late.v_keep.mean(),late.v_keep.median(),(late.v_keep>0).mean()))
print(late[['Year','Player','prior_rd','v_prior','v_keep','g_keep','rank_keep']].round(1).to_string(index=False))
r5=rb[(rb.prior_rd>=5)&(rb.prior_rd<=8)]
print("kept RBs drafted rd 5-8 (n=%d): prior %.1f -> keep %.1f"%(len(r5),r5.v_prior.mean(),r5.v_keep.mean()))
# bootstrap for kept-RB mean keep value
rng=np.random.default_rng(7); v=rb.v_keep.values; idx=rng.integers(0,len(v),(8000,len(v)))
print("kept RB E[VBD14 keep] = %.1f  95%% [%.1f, %.1f]"%(v.mean(),*np.quantile(v[idx].mean(1),[.025,.975])))
v=late.v_keep.values; idx=rng.integers(0,len(v),(8000,len(v)))
print("late kept RB E[VBD14 keep] = %.1f  95%% [%.1f, %.1f]  (n=%d, UNDERPOWERED)"%(v.mean(),*np.quantile(v[idx].mean(1),[.025,.975]),len(v)))

# (4) Matt's own keepers
H=pd.read_csv(SRC+'draft_history_2021_2025.csv')
mm=[m for m in H.Manager.unique() if 'JUG' in str(m).upper() or 'MAYS' in str(m).upper() or 'MATT' in str(m).upper()]
print("\nMatt manager string(s):",mm)
mk=K[K.Manager.isin(mm)] if mm else K.iloc[0:0]
print(mk[['Year','Player','Pos','prior_rd','v_prior','v_keep','g_keep']].round(1).to_string(index=False))

# (3) NFL-wide control via the registry (§1.1): late-ADP hits and their next season
rows=[]
for t in (2021,2022,2023,2024):
    adp=load_preseason_adp(t); adp['nk']=adp.player.map(norm)
    adp=adp.drop_duplicates('nk')
    st=S[S.season==t].merge(adp[['nk','adp']],on='nk',how='left')
    nxt=S[S.season==t+1].set_index('player_id')
    for _,r in st.iterrows():
        vn = nxt.vbd14.get(r.player_id, np.nan)
        if np.isnan(vn):   # no REG rows next season: zero season only if he had a market this year
            rp=S[(S.season==t+1)&(S.pos==r.pos)].repl14.iloc[0]; vn=-rp
        rows.append(dict(t=t,pid=r.player_id,name=r['name'],pos=r.pos,adp=r.adp,v_t=r.vbd14,g_t=r.g14,v_next=vn,
                         g_next=nxt.g14.get(r.player_id,0),rank_t=r.rank14,rank_next=nxt.rank14.get(r.player_id,np.nan)))
P=pd.DataFrame(rows); P.to_csv(D+'nfl_pool.csv',index=False)
print("\n=== NFL-wide, registry preseason ADP (§1.1): next-season VBD14 of this-season HITS (v_t>0), by ADP band ===")
def bs(x,B=6000,seed=3):
    x=np.asarray(x,float); n=len(x)
    if n<3: return (x.mean() if n else np.nan,np.nan,np.nan)
    idx=np.random.default_rng(seed).integers(0,n,(B,n)); m=x[idx].mean(1); return x.mean(),np.quantile(m,.025),np.quantile(m,.975)
bands=[('ADP 1-48 (rd 1-4)',1,48),('ADP 49-96 (rd 5-8)',49,96),('ADP 97+ (rd 9+)',97,999),('no preseason ADP',-1,-1)]
out=[]
for pos in ('RB','WR','QB','TE'):
    for lab,lo,hi in bands:
        if lo==-1: g=P[(P.pos==pos)&P.adp.isna()&(P.v_t>0)]
        else: g=P[(P.pos==pos)&P.adp.between(lo,hi)&(P.v_t>0)]
        m,l,h=bs(g.v_next)
        out.append(dict(pos=pos,band=lab,n=len(g),mean_v_t=g.v_t.mean(),mean_v_next=m,lo=l,hi=h,
                        ratio=(m/g.v_t.mean() if len(g) else np.nan),share_pos=(g.v_next>0).mean() if len(g) else np.nan,
                        g_t=g.g_t.mean(),g_next=g.g_next.mean()))
O=pd.DataFrame(out); print(O.round(2).to_string(index=False))
# regression benchmark controlling for hit size: RB hits 20<=v_t<=80, late vs early ADP
print("\n=== RB hits matched on size (20 <= v_t <= 80): late ADP (97+) vs early (1-48) vs mid (49-96) ===")
for lab,lo,hi in bands[:3]:
    g=P[(P.pos=='RB')&P.adp.between(lo,hi)&P.v_t.between(20,80)]
    m,l,h=bs(g.v_next); print(f"{lab}: n={len(g)}  v_t {g.v_t.mean():.1f} -> v_next {m:.1f} [{l:.1f},{h:.1f}]  games {g.g_t.mean():.1f}->{g.g_next.mean():.1f}  share>0 {(g.v_next>0).mean():.2f}")
# registry coverage check
for t in (2021,2022,2023,2024):
    g=P[(P.t==t)&(P.pos=='RB')&(P.v_t>0)]; print(f"{t}: RB hits n={len(g)}, with registry ADP {g.adp.notna().sum()}, ADP>=97 {(g.adp>=97).sum()}")
