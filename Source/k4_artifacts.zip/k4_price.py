"""Task #4 step 2/3: price pick-32 candidates in DOLLARS, paired (doc 70 design), on the CURRENT
shipped board, then re-score the same drafts with the §4.22(e) availability haircut.
Arms are policies: 'take X at 32 if on the board, else engine-best (QB2/TE1 shape, gate 104)'.
Scoring: doc 92 measured streaming fills; league H2H standings -> §2 payout. CRN across arms."""
import sys, time, numpy as np, pandas as pd
sys.path.insert(0,'/tmp/eng')
import engine, league
from engine import Sim, load
from league import PAYOUT, standings, ORDER, KEEP, POOL, band_of, N_TEAMS
from shapes import realise_fill, QBPOOL, TEPOOL
LD='/mnt/user-data/uploads/2026/Scripts/live_draft/'
b,_=load(LD+'board_v8_fixed.csv')
NAME={n:i for i,n in enumerate(b.player.values)}; ARSB=NAME['Amon-Ra St. Brown']
NW=14; MY=engine.MY_SLOT; GATE=104
FILLS=dict(QB=16.65,RB=6.60,WR=6.98,TE=6.49)
# ---- §4.22(e) dose-dependent shape, RELATIVE to the 13+ band (the outcome pool's form mean already
# carries the average shortfall; only the dose-dependent excess is new information)
G=pd.read_csv('/mnt/user-data/uploads/2026/Source/games_2025.csv')[['espn_id','g25']].groupby('espn_id',as_index=False).g25.max()  # file carries ONE duplicate id (Josh Williams, 2 vs 8 games)
g25=b[['espn_id']].merge(G,on='espn_id',how='left').g25.values
def haircut(g):
    if pd.isna(g) or g<0: return 0.0          # -1 = no 2025 season (rookie): no adjustment
    if g<=6: return -40.8+12.6
    if g<=9: return -27.1+12.6
    if g<=12: return -16.9+12.6
    return 0.0
HC=np.array([haircut(g) for g in g25])
PROJ0=b.proj_leaguepts.values.astype(float)
PROJ_ADJ=np.maximum(PROJ0+HC,0.0)
PROJ_ADJ_WR=np.where(b.pos.values=='WR',PROJ_ADJ,PROJ0)     # §4.22(c): the effect was entirely WR

SLATE=['Brock Bowers','Trey McBride','Kyren Williams','Quinshon Judkins','Davante Adams','Malik Nabers',
       'Garrett Wilson','DeVonta Smith','Emeka Egbuka','Tyler Warren','Joe Burrow','Jalen Hurts',
       'Lamar Jackson','Jayden Daniels',"D'Andre Swift",'Bucky Irving','Tee Higgins','Chase Brown','Omarion Hampton',
       'Matthew Stafford','Breece Hall']
SLATE=[s for s in SLATE if s in NAME]
Si=np.array([NAME[s] for s in SLATE])

def rule32(f32=None, trk=None):
    def rule(sim,avail,roster,counts,pk,left,rng):
        if trk is not None and pk==32: trk['a32']=avail[Si].copy()
        if pk==8:                                   # doc 70's arm: best NON-QB board player
            m=avail&(sim.pos!='QB'); i=int(np.argmax(np.where(m,sim.vbd,-np.inf)))
            if trk is not None: trk['p8']=i
            return i
        if pk==32 and f32 is not None and avail[f32]:
            if trk is not None: trk['got']=1; trk['p32']=f32
            return f32
        caps={'QB':2,'RB':6,'WR':6,'TE':1}; eff=dict(caps)
        if pk<GATE: eff['QB']=1
        ok={p for p in eff if counts.get(p,0)<eff[p]}
        need=[p for p in ('QB','TE') if counts.get(p,0)==0]
        if need and left<=len(need): ok=set(need)
        m=avail&np.isin(sim.pos,list(ok))
        if not m.any(): m=avail
        c=int(np.argmax(np.where(m,sim.vbd,-np.inf)))
        if trk is not None and pk==32: trk['p32']=c
        if trk is not None and pk==17: trk['p17']=c
        return c
    return rule

def outcome_draws(sim, s):
    orng=np.random.default_rng(270_000+s); n=sim.n
    fa=np.empty(n); la=np.zeros((n,NW),bool)
    for i in range(n):
        f,g=(QBPOOL if sim.pos[i]=='QB' else (TEPOOL if sim.pos[i]=='TE' else POOL[band_of(sim.adp_opp[i])]))
        t=orng.integers(0,len(f)); fa[i]=f[t]
        wk=orng.permutation(17)[:int(round(g[t]))]; la[i]=np.isin(np.arange(1,NW+1),wk+1)
    kform=np.empty(12); klive=np.zeros((12,NW),bool)
    kpos=[KEEP[KEEP.slot==sl].iloc[0].pos if len(KEEP[KEEP.slot==sl]) else '?' for sl in range(1,13)]
    for j in range(12):
        f,g=(QBPOOL if kpos[j]=='QB' else (TEPOOL if kpos[j]=='TE' else POOL[band_of(30.0)]))
        t=orng.integers(0,len(f)); kform[j]=f[t]
        wk=orng.permutation(17)[:int(round(g[t]))]; klive[j]=np.isin(np.arange(1,NW+1),wk+1)
    return fa,la,kform,klive

def run(seeds, arms, q=0.90):
    rows=[]
    for s in seeds:
        r0=np.random.default_rng(250_000+s)
        sim=Sim(b,198.68,r0); pref=sim.draw_pref(); sny=r0.random()<q
        fa,la,kform,klive=outcome_draws(sim,s)
        for aname,f32 in arms:
            trk={}
            ros=league.draft(sim,rule32(f32,trk),pref,np.random.default_rng(260_000+s),sny)
            d=dict(seed=s,arm=aname,got=trk.get('got',0),p8=sim.name[trk['p8']],p32=sim.name[trk['p32']],p17=sim.name[trk.get('p17',trk['p32'])])
            for k,nm in enumerate(SLATE): d['a32_'+nm.split()[-1]]=int(trk['a32'][k])
            for tag,pj in (('u',PROJ0),('a',PROJ_ADJ),('w',PROJ_ADJ_WR)):
                sim.proj=pj
                p=realise_fill(sim,ros,fa,la,kform,klive,FILLS)
                tot,rh,_=standings(p,np.random.default_rng(280_000+s))
                d[f'pts_{tag}']=tot[MY-1]; d[f'rank_{tag}']=int(rh[MY-1]); d[f'pay_{tag}']=PAYOUT.get(int(rh[MY-1]),0)
            sim.proj=PROJ0
            rows.append(d)
    return pd.DataFrame(rows)

if __name__=='__main__':
    n0,n1=int(sys.argv[1]),int(sys.argv[2])
    arms=[('ctrl32',None)]+[(s.split()[-1] if s!='Garrett Wilson' else 'GWilson',NAME[s]) for s in SLATE]
    t=time.time(); df=run(range(n0,n1),arms)
    D='/tmp/claude-0/-home-claude/7a129960-8604-52db-9d4d-5fd560a4a85d/scratchpad/k4/'
    df.to_csv(D+f'price32_{n0}_{n1}.csv',index=False)
    print(f'seeds {n0}-{n1}: {time.time()-t:.0f}s  arms={len(arms)}')
