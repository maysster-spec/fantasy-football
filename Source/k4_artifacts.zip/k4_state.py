"""Task #4 step 1: the PRODUCTION engine's candidates at pick 32, across realistic pick-32 states.
States come from the §5 opponent model (league.draft: best-VBD-in-window, affine noise on eff_pick,
Snyder q=0.90) on the CURRENT shipped board; Matt's 8 and 17 = best board player (doc 70 / doc 94).
The engine is code_live_engine.Engine built exactly as production builds it (§0.2 v5.5)."""
import sys, time, numpy as np, pandas as pd
sys.path.insert(0,'/tmp/eng'); sys.path.insert(0,'/mnt/user-data/uploads/2026/Scripts/live_draft')
import engine, league
from engine import Sim, load
from league import ORDER, N_TEAMS
import code_live_engine as CLE
LD='/mnt/user-data/uploads/2026/Scripts/live_draft/'
BOARD=LD+'board_v8_fixed.csv'
b,_=load(BOARD)
NAME={n:i for i,n in enumerate(b.player.values)}; ARSB=NAME['Amon-Ra St. Brown']
EID=b.espn_id.values.astype('int64')
MY=engine.MY_SLOT; GATE=104

def ctrl_rule(trk=None):
    def rule(sim,avail,roster,counts,pk,left,rng):
        if pk==8:
            i=ARSB
            if not avail[i]:
                m=avail&(sim.pos!='QB'); i=int(np.argmax(np.where(m,sim.vbd,-np.inf)))
            return i
        caps={'QB':2,'RB':6,'WR':6,'TE':1}; eff=dict(caps)
        if pk<GATE: eff['QB']=1
        ok={p for p in eff if counts.get(p,0)<eff[p]}
        need=[p for p in ('QB','TE') if counts.get(p,0)==0]
        if need and left<=len(need): ok=set(need)
        m=avail&np.isin(sim.pos,list(ok))
        if not m.any(): m=avail
        return int(np.argmax(np.where(m,sim.vbd,-np.inf)))
    return rule

def pick_order(rosters, upto):
    cnt={s:0 for s in range(1,N_TEAMS+1)}; seq=[]
    for pk in range(1,upto+1):
        sl=ORDER[pk-1]; c=rosters[sl][cnt[sl]]; cnt[sl]+=1; seq.append((pk,sl,c))
    return seq

def state(seed, q=0.90):
    r0=np.random.default_rng(250_000+seed)
    sim=Sim(b,198.68,r0); pref=sim.draw_pref(); sny=r0.random()<q
    ros=league.draft(sim,ctrl_rule(),pref,np.random.default_rng(260_000+seed),sny)
    return sim, pick_order(ros,31)

def run(seeds, inner=60, check_early=False):
    E=CLE.Engine(BOARD, LD+'ESPN_prerank_with_ids.csv')       # production object
    rows=[]; early=[]
    for s in seeds:
        sim,seq=state(s)
        taken=[int(EID[c]) for pk,sl,c in seq]; mine=[int(EID[c]) for pk,sl,c in seq if sl==MY]
        E.set_taken(taken,mine)
        t=time.time(); rec=E.recommend(32,top=12,reps=20,rollout_inner=inner); dt=time.time()-t
        for k,r in enumerate(rec):
            rows.append(dict(seed=s,rank=k+1,player=r['player'],pos=r['pos'],vbd=r['vbd'],adp=r['adp'],
                             roll=r['roll'],cost=r['cost'],mv=r['mv'],hold=r['hold'],delta=r['delta'],
                             p_next=r['p_next'],flag=r['flag'],my17=sim.name[[c for pk,sl,c in seq if pk==17][0]],
                             my8=sim.name[[c for pk,sl,c in seq if pk==8][0]],secs=round(dt,1)))
        if check_early:
            for P in (8,17):
                tk=[int(EID[c]) for pk,sl,c in seq if pk<P]; mn=[int(EID[c]) for pk,sl,c in seq if sl==MY and pk<P]
                E.set_taken(tk,mn); r2=E.recommend(P,top=12,reps=20,rollout_inner=inner)
                harness=sim.name[[c for pk,sl,c in seq if pk==P][0]]
                early.append(dict(seed=s,pick=P,engine=r2[0]['player'],harness=harness,
                                  agree=int(r2[0]['player']==harness),margin=round(r2[0]['roll']-r2[1]['roll'],2),
                                  runner=r2[1]['player']))
    return pd.DataFrame(rows), pd.DataFrame(early)

if __name__=='__main__':
    n0,n1=int(sys.argv[1]),int(sys.argv[2]); inner=int(sys.argv[3]) if len(sys.argv)>3 else 60
    chk=len(sys.argv)>4 and sys.argv[4]=='check'
    t=time.time(); df,ea=run(range(n0,n1),inner,chk)
    D='/tmp/claude-0/-home-claude/7a129960-8604-52db-9d4d-5fd560a4a85d/scratchpad/k4/'
    df.to_csv(D+f'state32_{n0}_{n1}_i{inner}.csv',index=False)
    if len(ea): ea.to_csv(D+f'early_{n0}_{n1}_i{inner}.csv',index=False)
    print(f'seeds {n0}-{n1} inner={inner}: {time.time()-t:.0f}s')
