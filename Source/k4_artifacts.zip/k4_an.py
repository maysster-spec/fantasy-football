"""Task #4 analysis: paired dollars at pick 32, unadjusted (u) vs availability-adjusted (a) vs WR-only (w)."""
import sys, glob, numpy as np, pandas as pd
D='/tmp/claude-0/-home-claude/7a129960-8604-52db-9d4d-5fd560a4a85d/scratchpad/k4/'
pd.set_option('display.width',250); pd.set_option('display.max_columns',40)
df=pd.concat([pd.read_csv(f) for f in sorted(glob.glob(D+'price32_*.csv'))],ignore_index=True)
N=df.seed.nunique(); arms=[a for a in df.arm.unique() if a!='ctrl32']
print(f'N seeds={N}, arms={len(arms)}')
rng=np.random.default_rng(11)
def bci(x,B=4000):
    x=np.asarray(x,float); n=len(x)
    if n<5: return (x.mean() if n else np.nan, np.nan, np.nan)
    idx=rng.integers(0,n,(B,n)); m=x[idx].mean(1); return x.mean(),np.quantile(m,.025),np.quantile(m,.975)
def q10ci(a,b,B=3000):
    a=np.asarray(a,float); b=np.asarray(b,float); n=len(a)
    if n<20: return (np.nan,np.nan,np.nan)
    idx=rng.integers(0,n,(B,n)); d=np.quantile(a[idx],.1,axis=1)-np.quantile(b[idx],.1,axis=1)
    return np.quantile(a,.1)-np.quantile(b,.1),np.quantile(d,.025),np.quantile(d,.975)

P={}
for tag in ('u','a','w'):
    P[tag]=df.pivot_table(index='seed',columns='arm',values=[f'pts_{tag}',f'pay_{tag}',f'rank_{tag}'])
got=df.pivot_table(index='seed',columns='arm',values='got')

def table(tag, cond):
    rows=[]
    for a in arms:
        seeds=got.index[got[a]==1] if cond else got.index
        if len(seeds)<20 and cond: rows.append(dict(arm=a,n=len(seeds))); continue
        pay=P[tag][f'pay_{tag}']; pts=P[tag][f'pts_{tag}']; rk=P[tag][f'rank_{tag}']
        dd=(pay.loc[seeds,a]-pay.loc[seeds,'ctrl32']).values; dp=(pts.loc[seeds,a]-pts.loc[seeds,'ctrl32']).values
        d1=((rk.loc[seeds,a]==1).astype(float)-(rk.loc[seeds,'ctrl32']==1).astype(float)).values
        d6=((rk.loc[seeds,a]<=6).astype(float)-(rk.loc[seeds,'ctrl32']<=6).astype(float)).values
        m,l,h=bci(dd); mp,lp,hp=bci(dp); m1,l1,h1=bci(d1); m6,l6,h6=bci(d6); q,ql,qh=q10ci(pts.loc[seeds,a],pts.loc[seeds,'ctrl32'])
        rows.append(dict(arm=a,n=len(seeds),avail=got[a].mean(),dpay=m,lo=l,hi=h,dpts=mp,pts_lo=lp,pts_hi=hp,
                         dP1=100*m1,dP1_lo=100*l1,dP1_hi=100*h1,dP6=100*m6,dP6_lo=100*l6,dP6_hi=100*h6,dp10=q,p10_lo=ql,p10_hi=qh))
    return pd.DataFrame(rows).sort_values('dpay',ascending=False)

for tag,lab in (('u','UNADJUSTED'),('a','AVAILABILITY-ADJUSTED (all positions)'),('w','WR-only adjustment')):
    print(f'\n===== {lab}: POLICY deltas vs ctrl32 (take X at 32 if there) =====')
    print(table(tag,False).round(2).to_string(index=False))
    print(f'\n===== {lab}: CONDITIONAL on X available at 32 =====')
    print(table(tag,True).round(2).to_string(index=False))

# pairwise on common-availability seeds, core candidates
core=['Bowers','McBride','Williams','Judkins','Adams','Egbuka','Smith','Nabers','GWilson','Jackson','Burrow','Hurts','Swift','Stafford','Daniels']
core=[c for c in core if c in arms]
for tag in ('u','a'):
    pay=P[tag][f'pay_{tag}']; M=pd.DataFrame(index=core,columns=core,dtype=float); Nn=pd.DataFrame(index=core,columns=core,dtype=float)
    LO=M.copy(); HI=M.copy()
    for a in core:
        for b_ in core:
            if a==b_: continue
            seeds=got.index[(got[a]==1)&(got[b_]==1)]
            if len(seeds)<30: M.loc[a,b_]=np.nan; Nn.loc[a,b_]=len(seeds); continue
            m,l,h=bci((pay.loc[seeds,a]-pay.loc[seeds,b_]).values); M.loc[a,b_]=m; LO.loc[a,b_]=l; HI.loc[a,b_]=h; Nn.loc[a,b_]=len(seeds)
    print(f'\n===== PAIRWISE Δ$ (row minus column), common-availability seeds, {"unadjusted" if tag=="u" else "adjusted"} =====')
    print(M.round(1).to_string())
    print('n per pair (min/median):', int(np.nanmin(Nn.values[Nn.values>0])) if (Nn.values>0).any() else 0, int(np.nanmedian(Nn.values[Nn.values>0])))
    # leads: does any row exceed +15 vs ALL columns with lo>0?
    for a in core:
        vals=M.loc[a].dropna(); los=LO.loc[a].dropna()
        if len(vals) and (vals>15).all() and (los>0).all(): print('  >> LEADER by >$15 clear of zero:',a)
    spread=np.nanmax(M.values)-0; print(f'  max pairwise |Δ$| among core: {np.nanmax(np.abs(M.values)):.1f}; pairs with CI clear of zero: '
          f'{int(((LO>0)|(HI<0)).values.sum()//1)} of {int(M.notna().values.sum())}')
    clear=[(a,b_,round(M.loc[a,b_],1)) for a in core for b_ in core if a!=b_ and pd.notna(M.loc[a,b_]) and (LO.loc[a,b_]>0)]
    print('  CI-clear positive pairs (row beats col):',clear)

print('\navailability at 32 (harness, §5 model):')
print(got.mean().sort_values(ascending=False).round(3).to_string())
print('\nctrl32 p32 (harness static-VBD choice):'); print(df[df.arm=='ctrl32'].p32.value_counts().head(12).to_string())
print('\np8 identity:'); print(df[df.arm=='ctrl32'].p8.value_counts().to_string())
print('p17:'); print(df[df.arm=='ctrl32'].p17.value_counts().head(8).to_string())
