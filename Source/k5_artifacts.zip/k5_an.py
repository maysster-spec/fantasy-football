"""Task #5 analysis: paired dollars at pick 17 (u/a/w scorings), Love vs Hall vs Lamb, core grid."""
import sys, glob, numpy as np, pandas as pd
D='/tmp/claude-0/-home-claude/7a129960-8604-52db-9d4d-5fd560a4a85d/scratchpad/k5/'
W=sys.argv[1] if len(sys.argv)>1 else '8'
pd.set_option('display.width',250); pd.set_option('display.max_columns',40)
df=pd.concat([pd.read_csv(f) for f in sorted(glob.glob(D+f'price17_w{W}_*.csv'))],ignore_index=True)
N=df.seed.nunique(); arms=[a for a in df.arm.unique() if a!='ctrl17']
print(f'W={W}  N seeds={N}, arms={len(arms)}')
rng=np.random.default_rng(11)
def bci(x,B=4000):
    x=np.asarray(x,float); n=len(x)
    if n<5: return (x.mean() if n else np.nan, np.nan, np.nan)
    idx=rng.integers(0,n,(B,n)); m=x[idx].mean(1); return x.mean(),np.quantile(m,.025),np.quantile(m,.975)
def q10ci(a,b,B=3000):
    a=np.asarray(a,float); b=np.asarray(b,float); n=len(a)
    if n<20: return (np.nan,np.nan,np.nan)
    idx=rng.integers(0,n,(B,n)); d=np.quantile(a[idx],.1,axis=1)-np.quantile(b[idx],.1,axis=1)
    return np.quantile(a,.1)-np.quantile(b,.1),np.quantile(d,.025),np.quantile(d,.975)
P={t:df.pivot_table(index='seed',columns='arm',values=[f'pts_{t}',f'pay_{t}',f'rank_{t}']) for t in ('u','a','w')}
got=df.pivot_table(index='seed',columns='arm',values='got')
def table(tag, cond):
    rows=[]
    for a in arms:
        seeds=got.index[got[a]==1] if cond else got.index
        if len(seeds)<20 and cond: rows.append(dict(arm=a,n=len(seeds))); continue
        pay=P[tag][f'pay_{tag}']; pts=P[tag][f'pts_{tag}']; rk=P[tag][f'rank_{tag}']
        dd=(pay.loc[seeds,a]-pay.loc[seeds,'ctrl17']).values; dp=(pts.loc[seeds,a]-pts.loc[seeds,'ctrl17']).values
        d1=((rk.loc[seeds,a]==1).astype(float)-(rk.loc[seeds,'ctrl17']==1).astype(float)).values
        d6=((rk.loc[seeds,a]<=6).astype(float)-(rk.loc[seeds,'ctrl17']<=6).astype(float)).values
        m,l,h=bci(dd); mp,lp,hp=bci(dp); m1,l1,h1=bci(d1); m6,l6,h6=bci(d6); q,ql,qh=q10ci(pts.loc[seeds,a],pts.loc[seeds,'ctrl17'])
        rows.append(dict(arm=a,n=len(seeds),avail=got[a].mean(),dpay=m,lo=l,hi=h,dpts=mp,pts_lo=lp,pts_hi=hp,
                         dP1=100*m1,dP1_lo=100*l1,dP1_hi=100*h1,dP6=100*m6,dP6_lo=100*l6,dP6_hi=100*h6,dp10=q,p10_lo=ql,p10_hi=qh))
    return pd.DataFrame(rows).sort_values('dpay',ascending=False)
for tag,lab in (('u','UNADJUSTED'),('a','AVAILABILITY-ADJUSTED (all positions)'),('w','WR-only adjustment')):
    print(f'\n===== {lab}: POLICY deltas vs ctrl17 =====');   print(table(tag,False).round(2).to_string(index=False))
    print(f'\n===== {lab}: CONDITIONAL on X available at 17 =====');   print(table(tag,True).round(2).to_string(index=False))
core=[c for c in ['Love','Hall','Lamb','Walker','Jeanty','Henry','CBrown','Hampton','Jefferson','Barkley','Achane','London','Bowers','McBride','Allen'] if c in arms]
for tag in ('u','a'):
    pay=P[tag][f'pay_{tag}']; pts=P[tag][f'pts_{tag}']
    M=pd.DataFrame(index=core,columns=core,dtype=float); LO=M.copy(); HI=M.copy(); Nn=M.copy(); MP=M.copy()
    for a in core:
        for b_ in core:
            if a==b_: continue
            seeds=got.index[(got[a]==1)&(got[b_]==1)]; Nn.loc[a,b_]=len(seeds)
            if len(seeds)<30: continue
            m,l,h=bci((pay.loc[seeds,a]-pay.loc[seeds,b_]).values); M.loc[a,b_]=m; LO.loc[a,b_]=l; HI.loc[a,b_]=h
            MP.loc[a,b_]=(pts.loc[seeds,a]-pts.loc[seeds,b_]).mean()
    print(f'\n===== PAIRWISE Δ$ (row minus column), common-availability seeds, {"unadjusted" if tag=="u" else "adjusted"} =====')
    print(M.round(1).to_string()); print('n:'); print(Nn.astype('Int64').to_string())
    clear=[(a,b_,round(M.loc[a,b_],1),int(Nn.loc[a,b_])) for a in core for b_ in core if a!=b_ and pd.notna(M.loc[a,b_]) and LO.loc[a,b_]>0]
    print('  CI-clear positive pairs (row beats col):',clear)
    for a in core:
        vals=M.loc[a].dropna(); los=LO.loc[a].dropna()
        if len(vals) and (vals>15).all() and (los>0).all(): print('  >> LEADER by >$15 clear of zero:',a)
    # headline pairs
    for a,b_ in (('Love','Hall'),('Love','Lamb'),('Love','Walker'),('Love','Jeanty'),('Love','Henry'),('Love','CBrown'),('Love','Hampton'),('Hall','Lamb'),('Walker','Jeanty'),('Walker','Hall'),('Jeanty','Hall')):
        if a in core and b_ in core and pd.notna(M.loc[a,b_]):
            print(f'  {a} - {b_}: ${M.loc[a,b_]:+.1f} [{LO.loc[a,b_]:+.1f},{HI.loc[a,b_]:+.1f}]  pts {MP.loc[a,b_]:+.1f}  n={int(Nn.loc[a,b_])}')
print('\navailability at 17 (harness, §5 model, window %s):'%W); print(got.mean().sort_values(ascending=False).round(3).to_string())
c=df[df.arm=='ctrl17']
print('\nctrl17 p17 (harness top VBD):'); print(c.p17.value_counts().head(10).to_string())
print('ctrl17 p32:'); print(c.p32.value_counts().head(8).to_string())
print('p8:'); print(c.p8.value_counts().to_string())
# survival to 32 of Hall/Love/Lamb/Walker/Jeanty under this window (ctrl arm, given available at 17)
for nm in ('Hall','Love','Lamb','Walker','Jeanty','CBrown','Hampton'):
    if f'a32_{nm}' in c:
        sub=c[c[f'a17_{nm}']==1]; print(f'P({nm} still there at 32 | there at 17, ctrl path) = {sub[f"a32_{nm}"].mean():.3f}  (n={len(sub)})')
# what the Love arm got at 32 vs what the Hall arm got at 32
for a in ('Love','Hall','Lamb','Walker'):
    if a in arms:
        g=df[(df.arm==a)&(df.got==1)]; print(f'{a} arm p32 top:', g.p32.value_counts().head(5).to_dict())
